document.querySelector("form").addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    const response = await fetch("http://localhost:8080/usuarios/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, senha })
    });

    if (response.ok) {
        const usuario = await response.json();

        // 🔐 Salva usuário no navegador
        localStorage.setItem("usuarioLogado", JSON.stringify(usuario));

        // 🚀 Redireciona
        window.location.href = "main.html";

    } else {
        alert("Email ou senha inválidos!");
    }
});
function abrirModal(){
document.getElementById("modalRecuperacao").style.display="flex"
}

function fecharModal(){
document.getElementById("modalRecuperacao").style.display="none"
}

function enviarEmailRecuperacao(){

const email=document.getElementById("emailRecuperar").value

fetch(`http://localhost:8080/usuarios/solicitar-recuperacao?email=${email}`,{
method:"POST"
})
.then(r=>{
if(r.ok){
document.getElementById("statusRecuperacao").innerText="Email enviado!"
}else{
document.getElementById("statusRecuperacao").innerText="Email não encontrado"
}
})

}
