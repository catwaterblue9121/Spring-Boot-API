const API = "http://localhost:8080/usuarios/login";

document.getElementById("formLogin")
.addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    fetch(API, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, senha })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Login inválido");
        }
        return response.json();
    })
    .then(usuario => {
        alert("Login realizado com sucesso!");
        window.location.href = "usuarios.html";
    })
    .catch(error => {
        document.getElementById("mensagem").textContent = error.message;
    });
});