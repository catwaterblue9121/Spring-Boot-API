package com.devsenai2a.schoolUserBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolUserBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
