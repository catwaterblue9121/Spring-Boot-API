const usuario = JSON.parse(localStorage.getItem("usuarioLogado"));

if (!usuario) {
    
    window.location.href = "login.html";
}

document.getElementById("nomeUsuario").textContent = usuario.nome;

function logout() {
    localStorage.removeItem("usuarioLogado");
    window.location.href = "index.html";
}