package com.gustavonog.db_usuarios2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbUsuariosversaodefinitivaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbUsuariosversaodefinitivaApplication.class, args);
	}

}
