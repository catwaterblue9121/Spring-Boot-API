package com.gabriel.db_usuariosversaodefinitiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbUsuariosversaodefinitivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
